package it.uniroma3.siw.taskmanager.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.taskmanager.model.Credentials;
import it.uniroma3.siw.taskmanager.model.User;
import it.uniroma3.siw.taskmanager.service.CredentialsService;
import it.uniroma3.siw.taskmanager.session.SessionData;
import it.uniroma3.siw.taskmanager.validator.CredentialsValidator;
import it.uniroma3.siw.taskmanager.validator.UserValidator;

@Controller
public class AuthenticationController {

	@Autowired
	CredentialsService credentialsService;
	
	@Autowired
	UserValidator userValidator;
	
	@Autowired
	CredentialsValidator credentialsValidator;
	
	@Autowired
	SessionData sessionData;
	
	@RequestMapping(value = {"/users/register"}, method = RequestMethod.GET)
	public String showRegisterForm (Model model) {
		model.addAttribute("userForm", new User());
		model.addAttribute("credentialsForm", new Credentials());
		
		return "registerUser";
	}
	
	@RequestMapping(value = {"/users/register"}, method = RequestMethod.POST)
	public String registerUser (@Valid @ModelAttribute("userForm") User user,
								BindingResult userBindingResult,
								@Valid @ModelAttribute("credentialsForm") Credentials credentials,
								BindingResult credentialsBindingResult,
								Model model) {
		
		//convalida i campi user e credenziali
		this.userValidator.validate(user, userBindingResult);
		this.credentialsValidator.validate(credentials, credentialsBindingResult);
		
		if(!userBindingResult.hasErrors()&&!credentialsBindingResult.hasErrors()) {
			credentials.setUser(user);
			credentialsService.saveCredentials(credentials);
			return "registrationSuccessful";
		}
		
		return "registerUser";
		
	}
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String customLoginHandler(Model model) {  
		if(sessionData.getCurrentCredentials() != null) {
			model.addAttribute("currentUser",sessionData.getLoggedUser());
			model.addAttribute("currentCredentials",sessionData.getLoggedCredentials());
			return "redirect:/home";
		}
		return "login";
	}
	
	
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logout(Model model) {
		this.sessionData.clear();
		return "index";
	}
	
	
	
}
