package it.uniroma3.siw.taskmanager.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.taskmanager.model.Comment;
import it.uniroma3.siw.taskmanager.model.Project;
import it.uniroma3.siw.taskmanager.model.Task;
import it.uniroma3.siw.taskmanager.model.User;
import it.uniroma3.siw.taskmanager.service.CommentService;
import it.uniroma3.siw.taskmanager.service.TaskService;
import it.uniroma3.siw.taskmanager.session.SessionData;
import it.uniroma3.siw.taskmanager.validator.CommentValidator;


@Controller
public class CommentController {

	@Autowired
	SessionData sessionData;
	
	@Autowired
	TaskService taskService; 
	
	@Autowired
	CommentService commentService;
	
	@Autowired
	CommentValidator commentValidator;
	
	
	/* ADD A COMMENT TO A TASK 
	 * NB: you can add a comment only if you are a member of 
	 * that project */
	@RequestMapping(value = {"/tasks/addComment"}, method = RequestMethod.GET)
	public String addCommentForm(Model model) {
		User loggedUser = this.sessionData.getLoggedUser();
		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("taskForm", new Task());
		model.addAttribute("commentForm", new Comment());
		return "addComment";
	}
	@RequestMapping(value = {"/tasks/addComment"}, method = RequestMethod.POST)
	public String addComment(@Valid@ModelAttribute("commentForm") Comment comment, 
			BindingResult commentResult, 
			@ModelAttribute("taskForm") Task task, 
			 Model model) {
		 
		User loggedUser = this.sessionData.getLoggedUser();
		
		/*verifica che il task è presente nel DB*/
		Task currentTask = this.taskService.getTask(task.getId());
		if(currentTask==null )
			return "addComment"; 
		/*verifica che il task fa parte dei progetti visibili dello user*/
		List<Project> visibleProjects = loggedUser.getVisibleProjects();
		Project projectWithTask = currentTask.getProject();
		if(!visibleProjects.contains(projectWithTask)) {
			return "addComment";
		}
		this.commentValidator.validate(comment, commentResult);
		if(!commentResult.hasErrors()) {
			this.commentService.saveComment(comment);
			currentTask.addComment(comment);
			this.taskService.saveTask(currentTask);
			return "addCommentSuccess"; 
		}
		return "addComment"; 
		
	}
	
	/*SHOW COMMENTS PAGE */
	@RequestMapping(value = {"/task/comments/{id}"}, method = RequestMethod.GET)
	public String showCommentsPage(@PathVariable("id") Long id, Model model) {
		User loggedUser = sessionData.getLoggedUser();
		Task currentTask = this.taskService.getTask(id);
		List<Comment>commentsList = currentTask.getComments();
		model.addAttribute("loggedUser", loggedUser);
		model.addAttribute("commentsList", commentsList);
		return "showComments";	
	}
	}
		
	
