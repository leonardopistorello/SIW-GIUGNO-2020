package it.uniroma3.siw.taskmanager.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import it.uniroma3.siw.taskmanager.model.Project;
import it.uniroma3.siw.taskmanager.model.Task;
import it.uniroma3.siw.taskmanager.model.User;
import it.uniroma3.siw.taskmanager.service.ProjectService;
import it.uniroma3.siw.taskmanager.service.TaskService;
import it.uniroma3.siw.taskmanager.service.UserService;
import it.uniroma3.siw.taskmanager.session.SessionData;
import it.uniroma3.siw.taskmanager.validator.TaskValidator;

@Controller
public class TaskController {

	@Autowired
	private TaskValidator taskValidator;

	@Autowired 
	private UserService userService;
	
	@Autowired 
	private ProjectService projectService;

	@Autowired
	private TaskService taskService;

	@Autowired 
	private SessionData sessionData;
	

/*AGGIUNTA DEI TASK AL PROGGETTO*/

	@RequestMapping(value= {"/tasks/add"},method=RequestMethod.GET)
	public String createTaskForm(Model model) {

		User loggedUser=sessionData.getLoggedUser();

		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("projectForm",new Project());
		model.addAttribute("taskForm",new Task());
		return "addTask";
	}

	@Lazy(value=false)
	@RequestMapping(value= {"/tasks/add"},method=RequestMethod.POST)
	public String createTaskOperation(
			@Valid @ModelAttribute("projectForm") Project project,
			@Valid @ModelAttribute("taskForm") Task task,
			BindingResult taskBindingResult,
			Model model)	                  
	{	

		User loggedUser=sessionData.getLoggedUser();
		taskValidator.validate(task,taskBindingResult);

		if(!taskBindingResult.hasErrors()) {
			if(this.projectService.getProject(project.getId())!=null
					&&this.projectService.getProject(project.getId()).getOwner().equals(loggedUser)
					&&this.taskService.getTask(task.getName())==null) {
				Project projectDefined=this.projectService.getProject(project.getId());
				task.setProject(projectDefined);
				this.taskService.saveTask(task);
				return "redirect:/projects/"+projectDefined.getId();
			}
		}
		model.addAttribute("loggedUser",loggedUser);
		return "addTask";
	}
	

	/*AGGIORNAMENTO DEI TASK*/
	
	@RequestMapping(value= {"/tasks/update"},method=RequestMethod.GET)
	public String modifyTaskForm(Model model) {

		User loggedUser=sessionData.getLoggedUser();

		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("projectForm",new Project());
		model.addAttribute("taskForm",new Task());
		return "updateTask";
	}

	@Lazy(value=false)
	@RequestMapping(value= {"/tasks/update"},method=RequestMethod.POST)
	public String modifyTaskOperation(
			@Valid @ModelAttribute("projectForm") Project project,
			@Valid @ModelAttribute("taskForm") Task task,
			BindingResult taskBindingResult,
			Model model)	                  
	{	

		User loggedUser=sessionData.getLoggedUser();


		if(this.projectService.getProject(project.getId())!=null&&this.projectService.getProject(project.getId()).getOwner().equals(loggedUser)) {

			Project projectDefined=this.projectService.getProject(project.getId());
			Task taskDefined=this.taskService.getTask(task.getName());
			if(this.taskService.getTask(task.getName())==null) {
				return "updateTask";}
			taskDefined.setName(task.getName());
			taskDefined.setDescription(task.getDescription());
			taskDefined.setCompleted(task.isCompleted());
			taskDefined.setProject(projectDefined);
			this.taskService.saveTask(taskDefined);
			return "updateTaskSuccess";
		}

		model.addAttribute("loggedUser",loggedUser);
		return "updateTask";
	}

	/*CANCELLLAZIONE TASK*/

	@RequestMapping(value= {"/tasks/delete"},method=RequestMethod.GET)
	public String deleteTask(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		model.addAttribute("user",loggedUser);
		model.addAttribute("projectForm",new Project());
		model.addAttribute("taskForm",new Task());
		return "deleteTask";
	}

	@RequestMapping(value= {"/tasks/delete"},method=RequestMethod.POST)
	public String deleteTaskSuccess(
			@Valid @ModelAttribute("projectForm") Project project,
			@Valid @ModelAttribute("taskForm") Task task,
			BindingResult projectBindingResult,Model model) {	
		
		User loggedUser=sessionData.getLoggedUser();
		Long id=project.getId();
		String taskname = task.getName();
		if(this.projectService.getProject(id)!=null&&this.projectService.getProject(id).getOwner().equals(loggedUser)&&this.taskService.getTask(taskname)!=null) {	

			Task taskDefined=this.taskService.getTask(task.getName());
			this.taskService.deleteTask(taskDefined);
			return "deleteTaskSuccess";	
		}
		model.addAttribute("loggedUser",loggedUser);
		return "deleteTask";
	}

	//--------------------------------------------------------------------------
	/*METHOD ASSIGNMENT TO 
	 * USER TO TASK
	 */
	@RequestMapping(value= {"/tasks/share"},method=RequestMethod.GET)
	public String addUsertoTask(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		model.addAttribute("user",loggedUser);
		model.addAttribute("projectForm",new Project());
		model.addAttribute("taskForm",new Task());
		model.addAttribute("userForm",new User());
		return "shareTask";
	}

	@RequestMapping(value= {"/tasks/share"},method=RequestMethod.POST)
	public String AddUserToTaskOperation(
			@Valid @ModelAttribute("projectForm") Project project,
			@Valid @ModelAttribute("taskForm") Task task,
			@Valid @ModelAttribute("userForm") User user,
			BindingResult taskBindingResult,
			Model model)	                  
	{	

		User loggedUser=sessionData.getLoggedUser();
		User userAssigned = this.userService.getUser(user.getFirstName(),user.getLastName());
		
		if(this.projectService.getProject(project.getId())!=null
				&&this.projectService.getProject(project.getId())
				.getOwner().equals(loggedUser)
				&&this.projectService.findMembers(userAssigned)!=null) {
			Task taskDefined=this.taskService.getTask(task.getName());
			if(this.taskService.getTask(task.getName())==null) {
				return "shareTask";}
			    taskDefined.setAssignedTo(userAssigned);
			    this.taskService.saveTask(taskDefined);
				userAssigned.addTask(taskDefined);
				userAssigned=this.userService.saveUser(userAssigned);
				model.addAttribute("user",userAssigned);
				return "shareTaskSuccess";
			}
		model.addAttribute("loggedUser",loggedUser);
		
		return "shareTask";
	}
}
