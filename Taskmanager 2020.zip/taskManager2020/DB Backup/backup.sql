--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

-- Started on 2020-06-18 18:39:32

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 203 (class 1259 OID 27857)
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id bigint NOT NULL,
    comment_text character varying(255) NOT NULL
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 27862)
-- Name: credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credentials (
    id bigint NOT NULL,
    password character varying(100) NOT NULL,
    role character varying(10) NOT NULL,
    user_name character varying(100) NOT NULL,
    user_id bigint
);


ALTER TABLE public.credentials OWNER TO postgres;

--
-- TOC entry 202 (class 1259 OID 27855)
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- TOC entry 205 (class 1259 OID 27867)
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    description character varying(255),
    name character varying(100) NOT NULL,
    owner_id bigint
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- TOC entry 206 (class 1259 OID 27872)
-- Name: projects_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects_members (
    visible_projects_id bigint NOT NULL,
    members_id bigint NOT NULL
);


ALTER TABLE public.projects_members OWNER TO postgres;

--
-- TOC entry 207 (class 1259 OID 27875)
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id bigint NOT NULL,
    completed boolean NOT NULL,
    description character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    assigned_to_id bigint,
    project_id bigint
);


ALTER TABLE public.task OWNER TO postgres;

--
-- TOC entry 208 (class 1259 OID 27883)
-- Name: task_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_comments (
    task_id bigint NOT NULL,
    comments_id bigint NOT NULL
);


ALTER TABLE public.task_comments OWNER TO postgres;

--
-- TOC entry 209 (class 1259 OID 27886)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    creation_timestamp timestamp without time zone NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    last_update_timestamp timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 2863 (class 0 OID 27857)
-- Dependencies: 203
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comment (id, comment_text) FROM stdin;
\.


--
-- TOC entry 2864 (class 0 OID 27862)
-- Dependencies: 204
-- Data for Name: credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credentials (id, password, role, user_name, user_id) FROM stdin;
\.


--
-- TOC entry 2865 (class 0 OID 27867)
-- Dependencies: 205
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, description, name, owner_id) FROM stdin;
\.


--
-- TOC entry 2866 (class 0 OID 27872)
-- Dependencies: 206
-- Data for Name: projects_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects_members (visible_projects_id, members_id) FROM stdin;
\.


--
-- TOC entry 2867 (class 0 OID 27875)
-- Dependencies: 207
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, completed, description, name, assigned_to_id, project_id) FROM stdin;
\.


--
-- TOC entry 2868 (class 0 OID 27883)
-- Dependencies: 208
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_comments (task_id, comments_id) FROM stdin;
\.


--
-- TOC entry 2869 (class 0 OID 27886)
-- Dependencies: 209
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, creation_timestamp, first_name, last_name, last_update_timestamp) FROM stdin;
\.


--
-- TOC entry 2875 (class 0 OID 0)
-- Dependencies: 202
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 1, false);


--
-- TOC entry 2713 (class 2606 OID 27861)
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- TOC entry 2715 (class 2606 OID 27866)
-- Name: credentials credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credentials
    ADD CONSTRAINT credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 2719 (class 2606 OID 27871)
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- TOC entry 2721 (class 2606 OID 27882)
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- TOC entry 2725 (class 2606 OID 27896)
-- Name: task_comments uk_2ai2rh4v34oftvibvlpfnc74b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT uk_2ai2rh4v34oftvibvlpfnc74b UNIQUE (comments_id);


--
-- TOC entry 2717 (class 2606 OID 27892)
-- Name: credentials uk_iruybducdoxd2f0vh3t8g6x5y; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credentials
    ADD CONSTRAINT uk_iruybducdoxd2f0vh3t8g6x5y UNIQUE (user_name);


--
-- TOC entry 2723 (class 2606 OID 27894)
-- Name: task uk_lerptdo9d67pejjpbfau899tm; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT uk_lerptdo9d67pejjpbfau899tm UNIQUE (name);


--
-- TOC entry 2727 (class 2606 OID 27890)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 2732 (class 2606 OID 27917)
-- Name: task fk3cjmgekj641ph0muq32huj8ux; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT fk3cjmgekj641ph0muq32huj8ux FOREIGN KEY (assigned_to_id) REFERENCES public.users(id);


--
-- TOC entry 2735 (class 2606 OID 27932)
-- Name: task_comments fk57giy29i5nak139pefvyvhj9h; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT fk57giy29i5nak139pefvyvhj9h FOREIGN KEY (task_id) REFERENCES public.task(id);


--
-- TOC entry 2733 (class 2606 OID 27922)
-- Name: task fk59mygkh6yxl8yj6j8ocg1k73a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT fk59mygkh6yxl8yj6j8ocg1k73a FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 2730 (class 2606 OID 27907)
-- Name: projects_members fk6ebvqqi6hao0mn5yqjkjqqrwl; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects_members
    ADD CONSTRAINT fk6ebvqqi6hao0mn5yqjkjqqrwl FOREIGN KEY (members_id) REFERENCES public.users(id);


--
-- TOC entry 2734 (class 2606 OID 27927)
-- Name: task_comments fk7sybm6byg0d319yp5b0xkvn9b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT fk7sybm6byg0d319yp5b0xkvn9b FOREIGN KEY (comments_id) REFERENCES public.comment(id);


--
-- TOC entry 2728 (class 2606 OID 27897)
-- Name: credentials fkcbcgksvnqvqxrrc4dwv3qys65; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credentials
    ADD CONSTRAINT fkcbcgksvnqvqxrrc4dwv3qys65 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 2729 (class 2606 OID 27902)
-- Name: projects fkmueqy6cpcwpfl8gnnag4idjt9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT fkmueqy6cpcwpfl8gnnag4idjt9 FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- TOC entry 2731 (class 2606 OID 27912)
-- Name: projects_members fkp7fwtdfobot07e3n296tlhn7f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects_members
    ADD CONSTRAINT fkp7fwtdfobot07e3n296tlhn7f FOREIGN KEY (visible_projects_id) REFERENCES public.projects(id);


-- Completed on 2020-06-18 18:39:33

--
-- PostgreSQL database dump complete
--

